
public class ClassExample3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
    Circle obj1= new Circle(3.0);
    
    obj1.getArea();
    
    System.out.println("���� ���� = " + obj1.getArea());

	}

}
